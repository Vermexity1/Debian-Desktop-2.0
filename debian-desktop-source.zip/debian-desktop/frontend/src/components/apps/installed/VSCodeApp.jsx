import { useState, useRef, useEffect, useCallback } from "react";
import { ChevronRight, ChevronDown, FilePlus, FolderPlus, Save, X, Search, Settings, Play, Terminal, GitBranch, Package } from "lucide-react";
import { fs } from "@/engines/filesystem";

const THEMES = {
  "One Dark": { bg: "#282c34", sidebar: "#21252b", editor: "#282c34", text: "#abb2bf", lineNum: "#4b5263", accent: "#528bff" },
  "Monokai": { bg: "#272822", sidebar: "#1e1f1c", editor: "#272822", text: "#f8f8f2", lineNum: "#75715e", accent: "#66d9e8" },
  "Solarized Dark": { bg: "#002b36", sidebar: "#073642", editor: "#002b36", text: "#839496", lineNum: "#586e75", accent: "#268bd2" },
  "GitHub Dark": { bg: "#0d1117", sidebar: "#161b22", editor: "#0d1117", text: "#c9d1d9", lineNum: "#484f58", accent: "#58a6ff" },
};

const LANG_COLORS = {
  js: "#f7df1e", jsx: "#61dafb", ts: "#3178c6", tsx: "#61dafb",
  py: "#3572A5", html: "#e34c26", css: "#563d7c", json: "#292929",
  md: "#083fa1", sh: "#89e051", txt: "#9a9996",
};

function getExt(name) { return name.split(".").pop().toLowerCase(); }
function getLangColor(name) { return LANG_COLORS[getExt(name)] || "#9a9996"; }

function tokenize(code, lang) {
  let result = code.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  if (lang === "js" || lang === "jsx" || lang === "ts" || lang === "tsx") {
    result = result
      .replace(/\b(const|let|var|function|return|if|else|for|while|class|import|export|from|default|async|await|new|this|typeof|instanceof|null|undefined|true|false|void|delete|in|of|switch|case|break|continue|try|catch|finally|throw|yield)\b/g, '<span style="color:#c678dd">$1</span>')
      .replace(/("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|`(?:[^`\\]|\\.)*`)/g, '<span style="color:#98c379">$1</span>')
      .replace(/(\/\/[^\n]*)/g, '<span style="color:#5c6370;font-style:italic">$1</span>')
      .replace(/\b(\d+\.?\d*)\b/g, '<span style="color:#d19a66">$1</span>');
  } else if (lang === "py") {
    result = result
      .replace(/\b(def|class|import|from|return|if|elif|else|for|while|in|not|and|or|True|False|None|pass|break|continue|with|as|try|except|finally|raise|lambda|yield|global|nonlocal|print)\b/g, '<span style="color:#c678dd">$1</span>')
      .replace(/("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')/g, '<span style="color:#98c379">$1</span>')
      .replace(/(#[^\n]*)/g, '<span style="color:#5c6370;font-style:italic">$1</span>')
      .replace(/\b(\d+\.?\d*)\b/g, '<span style="color:#d19a66">$1</span>');
  } else if (lang === "html") {
    result = result
      .replace(/(&lt;\/?[a-zA-Z][a-zA-Z0-9]*)/g, '<span style="color:#e06c75">$1</span>')
      .replace(/([a-zA-Z-]+=)("(?:[^"\\]|\\.)*")/g, '<span style="color:#d19a66">$1</span><span style="color:#98c379">$2</span>');
  } else if (lang === "css") {
    result = result
      .replace(/([.#]?[a-zA-Z][a-zA-Z0-9_-]*)\s*\{/g, '<span style="color:#e06c75">$1</span>{')
      .replace(/([\w-]+)\s*:/g, '<span style="color:#61afef">$1</span>:')
      .replace(/:\s*([^;{}\n]+)/g, ': <span style="color:#98c379">$1</span>');
  } else if (lang === "json") {
    result = result
      .replace(/("(?:[^"\\]|\\.)*")\s*:/g, '<span style="color:#e06c75">$1</span>:')
      .replace(/:\s*("(?:[^"\\]|\\.)*")/g, ': <span style="color:#98c379">$1</span>')
      .replace(/\b(true|false|null)\b/g, '<span style="color:#d19a66">$1</span>')
      .replace(/\b(\d+\.?\d*)\b/g, '<span style="color:#d19a66">$1</span>');
  }
  return result;
}

export default function VSCodeApp() {
  const [theme, setTheme] = useState("One Dark");
  const colors = THEMES[theme];
  const [openFiles, setOpenFiles] = useState([]);
  const [activeFile, setActiveFile] = useState(null);
  const [fileContents, setFileContents] = useState({});
  const [modified, setModified] = useState({});
  const [sidebarTab, setSidebarTab] = useState("explorer");
  const [showSidebar, setShowSidebar] = useState(true);
  const [showTerminal, setShowTerminal] = useState(false);
  const [terminalLines, setTerminalLines] = useState(["$ "]);
  const [termInput, setTermInput] = useState("");
  const [expandedDirs, setExpandedDirs] = useState({ "/home/user": true });
  const [dirContents, setDirContents] = useState({});
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const textareaRef = useRef(null);
  const highlightRef = useRef(null);

  // Load directory
  const loadDir = useCallback(async (path) => {
    const children = await fs.readDir(path);
    if (children) {
      setDirContents((d) => ({ ...d, [path]: children }));
    }
  }, []);

  useEffect(() => { loadDir("/home/user"); }, [loadDir]);

  const toggleDir = async (path) => {
    setExpandedDirs((e) => {
      const next = { ...e, [path]: !e[path] };
      return next;
    });
    if (!expandedDirs[path]) await loadDir(path);
  };

  const openFile = async (path) => {
    if (!openFiles.includes(path)) {
      const content = await fs.readFile(path);
      setFileContents((c) => ({ ...c, [path]: content || "" }));
      setOpenFiles((f) => [...f, path]);
    }
    setActiveFile(path);
  };

  const closeFile = (path, e) => {
    e.stopPropagation();
    if (modified[path] && !window.confirm("Close without saving?")) return;
    setOpenFiles((f) => f.filter((p) => p !== path));
    if (activeFile === path) {
      const remaining = openFiles.filter((p) => p !== path);
      setActiveFile(remaining[remaining.length - 1] || null);
    }
    setModified((m) => { const next = { ...m }; delete next[path]; return next; });
  };

  const saveFile = useCallback(async () => {
    if (!activeFile) return;
    await fs.writeFile(activeFile, fileContents[activeFile] || "");
    setModified((m) => ({ ...m, [activeFile]: false }));
  }, [activeFile, fileContents]);

  useEffect(() => {
    const handler = (e) => {
      if (e.ctrlKey && e.key === "s") { e.preventDefault(); saveFile(); }
      if (e.ctrlKey && e.key === "`") { e.preventDefault(); setShowTerminal((t) => !t); }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [saveFile]);

  const handleEdit = (value) => {
    if (!activeFile) return;
    setFileContents((c) => ({ ...c, [activeFile]: value }));
    setModified((m) => ({ ...m, [activeFile]: true }));
  };

  const handleTab = (e) => {
    if (e.key === "Tab") {
      e.preventDefault();
      const ta = textareaRef.current;
      const start = ta.selectionStart, end = ta.selectionEnd;
      const content = fileContents[activeFile] || "";
      const newContent = content.slice(0, start) + "  " + content.slice(end);
      handleEdit(newContent);
      setTimeout(() => { ta.selectionStart = ta.selectionEnd = start + 2; }, 0);
    }
  };

  const syncScroll = () => {
    if (highlightRef.current && textareaRef.current) {
      highlightRef.current.scrollTop = textareaRef.current.scrollTop;
    }
  };

  const activeContent = activeFile ? (fileContents[activeFile] || "") : "";
  const activeExt = activeFile ? getExt(activeFile.split("/").pop()) : "txt";
  const lines = activeContent.split("\n");

  const handleSearch = async () => {
    if (!searchQuery) return;
    const results = [];
    const searchDir = async (path) => {
      const children = await fs.readDir(path);
      if (!children) return;
      for (const child of children) {
        const fp = path + "/" + child;
        const node = fs.stat(fp);
        if (node?.type === "file") {
          const content = await fs.readFile(fp);
          if (content?.includes(searchQuery)) {
            const matchLines = content.split("\n").filter((l) => l.includes(searchQuery));
            results.push({ file: fp, matches: matchLines.slice(0, 3) });
          }
        } else if (node?.type === "dir") {
          await searchDir(fp);
        }
      }
    };
    await searchDir("/home/user");
    setSearchResults(results);
  };

  const renderTree = (path, depth = 0) => {
    const children = dirContents[path] || [];
    const isExpanded = expandedDirs[path];
    return children.map((name) => {
      const fullPath = path + "/" + name;
      const node = fs.stat(fullPath);
      const isDir = node?.type === "dir";
      return (
        <div key={fullPath}>
          <div
            onClick={() => isDir ? toggleDir(fullPath) : openFile(fullPath)}
            style={{
              display: "flex", alignItems: "center", gap: 4,
              padding: `2px 8px 2px ${depth * 12 + 8}px`,
              cursor: "pointer", fontSize: "0.75rem",
              color: activeFile === fullPath ? "white" : "#abb2bf",
              background: activeFile === fullPath ? "rgba(82,139,255,0.2)" : "transparent",
            }}
          >
            {isDir ? (
              expandedDirs[fullPath] ? <ChevronDown size={10} /> : <ChevronRight size={10} />
            ) : (
              <span style={{ width: 10, height: 10, borderRadius: "50%", background: getLangColor(name), display: "inline-block", flexShrink: 0 }} />
            )}
            <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{name}</span>
          </div>
          {isDir && expandedDirs[fullPath] && renderTree(fullPath, depth + 1)}
        </div>
      );
    });
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: colors.bg, color: colors.text, fontFamily: "'Fira Code', monospace" }} data-testid="vscode-app">
      {/* Activity bar */}
      <div style={{ display: "flex", height: "100%", overflow: "hidden" }}>
        <div style={{ width: 44, background: "#333333", display: "flex", flexDirection: "column", alignItems: "center", padding: "8px 0", gap: 8, flexShrink: 0 }}>
          {[
            { id: "explorer", icon: <span style={{ fontSize: "1rem" }}>📁</span>, label: "Explorer" },
            { id: "search", icon: <Search size={18} />, label: "Search" },
            { id: "git", icon: <GitBranch size={18} />, label: "Source Control" },
            { id: "extensions", icon: <Package size={18} />, label: "Extensions" },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => { setSidebarTab(item.id); setShowSidebar(sidebarTab !== item.id || !showSidebar); }}
              title={item.label}
              style={{
                width: 36, height: 36, background: "none", border: "none",
                color: sidebarTab === item.id && showSidebar ? "white" : "#858585",
                cursor: "pointer", borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center",
                borderLeft: sidebarTab === item.id && showSidebar ? "2px solid white" : "2px solid transparent",
              }}
            >{item.icon}</button>
          ))}
          <div style={{ flex: 1 }} />
          <button onClick={() => {}} style={{ width: 36, height: 36, background: "none", border: "none", color: "#858585", cursor: "pointer", borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Settings size={18} />
          </button>
        </div>

        {/* Sidebar */}
        {showSidebar && (
          <div style={{ width: 220, background: colors.sidebar, borderRight: "1px solid rgba(255,255,255,0.08)", display: "flex", flexDirection: "column", overflow: "hidden", flexShrink: 0 }}>
            <div style={{ padding: "8px 12px", fontSize: "0.65rem", color: "#858585", textTransform: "uppercase", letterSpacing: 1 }}>
              {sidebarTab === "explorer" ? "Explorer" : sidebarTab === "search" ? "Search" : sidebarTab === "git" ? "Source Control" : "Extensions"}
            </div>

            {sidebarTab === "explorer" && (
              <div style={{ flex: 1, overflowY: "auto" }}>
                <div style={{ padding: "4px 8px", fontSize: "0.7rem", color: "#858585", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <span>OPEN EDITORS</span>
                </div>
                {openFiles.map((f) => (
                  <div key={f} onClick={() => setActiveFile(f)} style={{ display: "flex", alignItems: "center", gap: 4, padding: "2px 8px", cursor: "pointer", background: activeFile === f ? "rgba(82,139,255,0.2)" : "transparent", fontSize: "0.75rem", color: activeFile === f ? "white" : "#abb2bf" }}>
                    <span style={{ width: 8, height: 8, borderRadius: "50%", background: getLangColor(f.split("/").pop()), flexShrink: 0 }} />
                    <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{f.split("/").pop()}</span>
                    {modified[f] && <span style={{ color: "#e2c08d", fontSize: "0.6rem" }}>●</span>}
                    <button onClick={(e) => closeFile(f, e)} style={{ background: "none", border: "none", color: "#858585", cursor: "pointer", padding: 0, opacity: 0.6 }}><X size={10} /></button>
                  </div>
                ))}
                <div style={{ padding: "4px 8px", fontSize: "0.7rem", color: "#858585", marginTop: 4 }}>FILES</div>
                {renderTree("/home/user")}
              </div>
            )}

            {sidebarTab === "search" && (
              <div style={{ flex: 1, padding: 8, display: "flex", flexDirection: "column", gap: 8 }}>
                <input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  placeholder="Search..."
                  style={{ background: "#3c3c3c", border: "1px solid #555", borderRadius: 4, color: "white", padding: "4px 8px", fontSize: "0.75rem", outline: "none" }}
                />
                <button onClick={handleSearch} style={{ padding: "4px 8px", background: "#0e639c", border: "none", borderRadius: 4, color: "white", cursor: "pointer", fontSize: "0.75rem" }}>Search</button>
                <div style={{ flex: 1, overflowY: "auto" }}>
                  {searchResults.map((r, i) => (
                    <div key={i} style={{ marginBottom: 8 }}>
                      <div onClick={() => openFile(r.file)} style={{ fontSize: "0.75rem", color: "#e2c08d", cursor: "pointer", marginBottom: 2 }}>{r.file.split("/").pop()}</div>
                      {r.matches.map((m, j) => (
                        <div key={j} style={{ fontSize: "0.7rem", color: "#abb2bf", paddingLeft: 8, fontFamily: "monospace" }}>{m.trim().slice(0, 60)}</div>
                      ))}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {sidebarTab === "git" && (
              <div style={{ flex: 1, padding: 12 }}>
                <div style={{ fontSize: "0.75rem", color: "#abb2bf", marginBottom: 8 }}>
                  <div style={{ marginBottom: 4 }}>Branch: <span style={{ color: "#e2c08d" }}>main</span></div>
                  <div style={{ marginBottom: 4 }}>Changes: {Object.keys(modified).filter((k) => modified[k]).length}</div>
                </div>
                {Object.keys(modified).filter((k) => modified[k]).map((f) => (
                  <div key={f} style={{ fontSize: "0.7rem", color: "#e2c08d", padding: "2px 0" }}>M {f.split("/").pop()}</div>
                ))}
              </div>
            )}

            {sidebarTab === "extensions" && (
              <div style={{ flex: 1, padding: 8 }}>
                {["ESLint", "Prettier", "GitLens", "Python", "Tailwind CSS"].map((ext) => (
                  <div key={ext} style={{ padding: "6px 8px", fontSize: "0.75rem", color: "#abb2bf", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
                    <div style={{ color: "white" }}>{ext}</div>
                    <div style={{ fontSize: "0.65rem", color: "#858585" }}>Installed</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Main editor */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
          {/* Tabs */}
          <div style={{ display: "flex", background: "#252526", borderBottom: "1px solid rgba(255,255,255,0.08)", overflowX: "auto", flexShrink: 0 }}>
            {openFiles.map((f) => (
              <div
                key={f}
                onClick={() => setActiveFile(f)}
                style={{
                  display: "flex", alignItems: "center", gap: 6, padding: "6px 12px",
                  background: activeFile === f ? colors.bg : "transparent",
                  borderTop: activeFile === f ? `2px solid ${colors.accent}` : "2px solid transparent",
                  cursor: "pointer", flexShrink: 0, minWidth: 80, maxWidth: 160,
                }}
              >
                <span style={{ width: 8, height: 8, borderRadius: "50%", background: getLangColor(f.split("/").pop()), flexShrink: 0 }} />
                <span style={{ fontSize: "0.75rem", color: activeFile === f ? "white" : "#858585", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {f.split("/").pop()}
                </span>
                {modified[f] && <span style={{ color: "#e2c08d", fontSize: "0.6rem" }}>●</span>}
                <button onClick={(e) => closeFile(f, e)} style={{ background: "none", border: "none", color: "#858585", cursor: "pointer", padding: 0, opacity: 0.6, flexShrink: 0 }}><X size={10} /></button>
              </div>
            ))}
          </div>

          {/* Editor */}
          {activeFile ? (
            <div style={{ flex: 1, display: "flex", overflow: "hidden", fontSize: "13px", lineHeight: "1.6" }}>
              {/* Line numbers */}
              <div style={{ width: 44, background: colors.bg, padding: "12px 0", overflowY: "hidden", flexShrink: 0, userSelect: "none", textAlign: "right", color: colors.lineNum, fontSize: "12px" }}>
                {lines.map((_, i) => <div key={i} style={{ paddingRight: 8 }}>{i + 1}</div>)}
              </div>
              {/* Code area */}
              <div style={{ flex: 1, position: "relative", overflow: "hidden" }}>
                <div
                  ref={highlightRef}
                  style={{ position: "absolute", inset: 0, padding: "12px 12px", whiteSpace: "pre", overflowY: "auto", overflowX: "auto", color: colors.text, pointerEvents: "none", zIndex: 1 }}
                  dangerouslySetInnerHTML={{ __html: tokenize(activeContent, activeExt) + "\n" }}
                />
                <textarea
                  ref={textareaRef}
                  value={activeContent}
                  onChange={(e) => handleEdit(e.target.value)}
                  onKeyDown={handleTab}
                  onScroll={syncScroll}
                  spellCheck={false}
                  style={{
                    position: "absolute", inset: 0, padding: "12px 12px",
                    background: "transparent", border: "none", outline: "none",
                    resize: "none", color: "transparent", caretColor: "white",
                    fontFamily: "inherit", fontSize: "inherit", lineHeight: "inherit",
                    whiteSpace: "pre", overflowY: "auto", overflowX: "auto", zIndex: 2,
                  }}
                  data-testid="vscode-editor"
                />
              </div>
            </div>
          ) : (
            <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 16, color: "#858585" }}>
              <div style={{ fontSize: "3rem" }}>⌨️</div>
              <div style={{ fontSize: "1rem" }}>Visual Studio Code</div>
              <div style={{ fontSize: "0.8rem" }}>Open a file to start editing</div>
              <div style={{ display: "flex", gap: 8 }}>
                <select value={theme} onChange={(e) => setTheme(e.target.value)} style={{ background: "#3c3c3c", border: "1px solid #555", borderRadius: 4, color: "white", padding: "4px 8px", fontSize: "0.75rem" }}>
                  {Object.keys(THEMES).map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            </div>
          )}

          {/* Integrated terminal */}
          {showTerminal && (
            <div style={{ height: 160, background: "#1e1e1e", borderTop: "1px solid rgba(255,255,255,0.1)", display: "flex", flexDirection: "column" }}>
              <div style={{ display: "flex", alignItems: "center", padding: "4px 8px", background: "#252526", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
                <span style={{ fontSize: "0.7rem", color: "#858585" }}>TERMINAL</span>
                <div style={{ flex: 1 }} />
                <button onClick={() => setShowTerminal(false)} style={{ background: "none", border: "none", color: "#858585", cursor: "pointer" }}><X size={12} /></button>
              </div>
              <div style={{ flex: 1, overflowY: "auto", padding: "4px 8px", fontFamily: "monospace", fontSize: "0.8rem" }}>
                {terminalLines.map((line, i) => (
                  <div key={i} style={{ color: "#abb2bf" }}>{line}</div>
                ))}
              </div>
              <div style={{ display: "flex", padding: "4px 8px", alignItems: "center" }}>
                <span style={{ color: "#26a269", fontSize: "0.8rem", marginRight: 4 }}>$</span>
                <input
                  value={termInput}
                  onChange={(e) => setTermInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      setTerminalLines((l) => [...l, `$ ${termInput}`, `Command not found: ${termInput.split(" ")[0]}`]);
                      setTermInput("");
                    }
                  }}
                  style={{ flex: 1, background: "none", border: "none", color: "white", outline: "none", fontFamily: "monospace", fontSize: "0.8rem" }}
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Status bar */}
      <div style={{ height: 22, background: colors.accent, display: "flex", alignItems: "center", gap: 12, padding: "0 12px", fontSize: "0.65rem", color: "white", flexShrink: 0 }}>
        <GitBranch size={10} />
        <span>main</span>
        <span style={{ flex: 1 }} />
        {activeFile && (
          <>
            <span>{activeFile.split("/").pop()}</span>
            <span>{activeExt.toUpperCase()}</span>
            <span>{lines.length} lines</span>
          </>
        )}
        <button onClick={() => setShowTerminal(!showTerminal)} style={{ background: "none", border: "none", color: "white", cursor: "pointer", fontSize: "0.65rem", display: "flex", alignItems: "center", gap: 2 }}>
          <Terminal size={10} />Terminal
        </button>
      </div>
    </div>
  );
}
