import { useState, useRef, useEffect, useCallback } from "react";
import {
  Bold, Italic, Underline, AlignLeft, AlignCenter, AlignRight, AlignJustify,
  List, ListOrdered, Indent, Outdent, Link, Image, Table, Save, FolderOpen,
  FilePlus, Printer, Undo, Redo, Search, Type, Strikethrough,
} from "lucide-react";

const FONTS = ["Arial", "Times New Roman", "Courier New", "Georgia", "Verdana", "Helvetica", "Trebuchet MS", "Comic Sans MS"];
const FONT_SIZES = [8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 36, 48, 72];

export default function LibreOfficeApp() {
  const editorRef = useRef(null);
  const [fontFamily, setFontFamily] = useState("Arial");
  const [fontSize, setFontSize] = useState(12);
  const [wordCount, setWordCount] = useState(0);
  const [charCount, setCharCount] = useState(0);
  const [modified, setModified] = useState(false);
  const [fileName, setFileName] = useState("Untitled Document");
  const [showSearch, setShowSearch] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [replaceTerm, setReplaceTerm] = useState("");
  const [zoom, setZoom] = useState(100);
  const [showTable, setShowTable] = useState(false);
  const [tableRows, setTableRows] = useState(3);
  const [tableCols, setTableCols] = useState(3);
  const [pageCount, setPageCount] = useState(1);

  const exec = (command, value = null) => {
    editorRef.current?.focus();
    document.execCommand(command, false, value);
    updateStats();
  };

  const updateStats = () => {
    if (!editorRef.current) return;
    const text = editorRef.current.innerText || "";
    setWordCount(text.trim() ? text.trim().split(/\s+/).length : 0);
    setCharCount(text.length);
    setModified(true);
    // Estimate page count (rough: 500 words per page)
    const words = text.trim() ? text.trim().split(/\s+/).length : 0;
    setPageCount(Math.max(1, Math.ceil(words / 500)));
  };

  const applyFont = (font) => {
    setFontFamily(font);
    exec("fontName", font);
  };

  const applyFontSize = (size) => {
    setFontSize(size);
    exec("fontSize", Math.ceil(size / 4));
    // Override with inline style
    const sel = window.getSelection();
    if (sel && sel.rangeCount > 0 && !sel.isCollapsed) {
      const range = sel.getRangeAt(0);
      const span = document.createElement("span");
      span.style.fontSize = size + "pt";
      range.surroundContents(span);
    }
  };

  const insertTable = () => {
    let html = `<table border="1" style="border-collapse:collapse;width:100%;margin:8px 0">`;
    for (let r = 0; r < tableRows; r++) {
      html += "<tr>";
      for (let c = 0; c < tableCols; c++) {
        html += r === 0
          ? `<th style="padding:6px 10px;background:#f0f0f0;border:1px solid #ccc">Header ${c + 1}</th>`
          : `<td style="padding:6px 10px;border:1px solid #ccc">&nbsp;</td>`;
      }
      html += "</tr>";
    }
    html += "</table><p><br></p>";
    exec("insertHTML", html);
    setShowTable(false);
  };

  const insertLink = () => {
    const url = prompt("Enter URL:", "https://");
    if (url) exec("createLink", url);
  };

  const handleSearch = () => {
    if (!searchTerm) return;
    const content = editorRef.current?.innerHTML || "";
    const highlighted = content.replace(
      new RegExp(searchTerm.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi"),
      (m) => `<mark style="background:#f8e45c;color:#000">${m}</mark>`
    );
    if (editorRef.current) editorRef.current.innerHTML = highlighted;
  };

  const handleReplace = () => {
    if (!searchTerm) return;
    const content = editorRef.current?.innerHTML || "";
    const replaced = content.replace(
      new RegExp(searchTerm.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi"),
      replaceTerm
    );
    if (editorRef.current) editorRef.current.innerHTML = replaced;
  };

  const handleSave = () => {
    const content = editorRef.current?.innerHTML || "";
    const blob = new Blob([`<!DOCTYPE html><html><body>${content}</body></html>`], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = fileName + ".html"; a.click();
    setModified(false);
  };

  const handlePrint = () => {
    const content = editorRef.current?.innerHTML || "";
    const win = window.open("", "_blank");
    win.document.write(`<!DOCTYPE html><html><head><title>${fileName}</title><style>body{font-family:Arial;margin:2cm;}</style></head><body>${content}</body></html>`);
    win.document.close();
    win.print();
  };

  const toolbarBtn = (cmd, icon, title, value = null) => (
    <button
      onMouseDown={(e) => { e.preventDefault(); exec(cmd, value); }}
      style={tbBtn}
      title={title}
      data-testid={`lo-${cmd}`}
    >{icon}</button>
  );

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#f5f5f5" }} data-testid="libreoffice-app">
      {/* Menu bar */}
      <div style={{ display: "flex", alignItems: "center", gap: 4, padding: "4px 8px", background: "#e8e8e8", borderBottom: "1px solid #ccc", flexWrap: "wrap" }}>
        <button onClick={() => { if (editorRef.current) { editorRef.current.innerHTML = ""; setModified(false); setFileName("Untitled Document"); } }} style={menuBtnStyle}><FilePlus size={12} />New</button>
        <button onClick={handleSave} style={menuBtnStyle}><Save size={12} />Save</button>
        <button onClick={handlePrint} style={menuBtnStyle}><Printer size={12} />Print</button>
        <div style={{ width: 1, height: 14, background: "#ccc", margin: "0 4px" }} />
        <button onMouseDown={(e) => { e.preventDefault(); exec("undo"); }} style={menuBtnStyle}><Undo size={12} />Undo</button>
        <button onMouseDown={(e) => { e.preventDefault(); exec("redo"); }} style={menuBtnStyle}><Redo size={12} />Redo</button>
        <div style={{ width: 1, height: 14, background: "#ccc", margin: "0 4px" }} />
        <button onClick={() => setShowSearch(!showSearch)} style={{ ...menuBtnStyle, color: showSearch ? "#3584e4" : undefined }}><Search size={12} />Find</button>
        <div style={{ flex: 1 }} />
        <input
          value={fileName}
          onChange={(e) => setFileName(e.target.value)}
          style={{ background: "none", border: "none", outline: "none", fontSize: "0.8rem", color: "#333", fontWeight: 600, textAlign: "center", width: 200 }}
        />
        {modified && <span style={{ fontSize: "0.7rem", color: "#e66100" }}>● Modified</span>}
        <div style={{ flex: 1 }} />
        <select value={zoom} onChange={(e) => setZoom(Number(e.target.value))} style={{ background: "#e8e8e8", border: "1px solid #ccc", borderRadius: 4, padding: "2px 4px", fontSize: "0.7rem" }}>
          {[50, 75, 100, 125, 150, 200].map((z) => <option key={z} value={z}>{z}%</option>)}
        </select>
      </div>

      {/* Formatting toolbar */}
      <div style={{ display: "flex", alignItems: "center", gap: 2, padding: "4px 8px", background: "#eeeeee", borderBottom: "1px solid #ccc", flexWrap: "wrap" }}>
        {/* Font */}
        <select value={fontFamily} onChange={(e) => applyFont(e.target.value)} style={{ background: "white", border: "1px solid #ccc", borderRadius: 3, padding: "2px 4px", fontSize: "0.75rem", width: 120 }}>
          {FONTS.map((f) => <option key={f} value={f} style={{ fontFamily: f }}>{f}</option>)}
        </select>
        <select value={fontSize} onChange={(e) => applyFontSize(Number(e.target.value))} style={{ background: "white", border: "1px solid #ccc", borderRadius: 3, padding: "2px 4px", fontSize: "0.75rem", width: 50 }}>
          {FONT_SIZES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <div style={{ width: 1, height: 14, background: "#ccc", margin: "0 2px" }} />
        {toolbarBtn("bold", <Bold size={13} />, "Bold (Ctrl+B)")}
        {toolbarBtn("italic", <Italic size={13} />, "Italic (Ctrl+I)")}
        {toolbarBtn("underline", <Underline size={13} />, "Underline (Ctrl+U)")}
        {toolbarBtn("strikeThrough", <Strikethrough size={13} />, "Strikethrough")}
        <div style={{ width: 1, height: 14, background: "#ccc", margin: "0 2px" }} />
        {toolbarBtn("justifyLeft", <AlignLeft size={13} />, "Align Left")}
        {toolbarBtn("justifyCenter", <AlignCenter size={13} />, "Center")}
        {toolbarBtn("justifyRight", <AlignRight size={13} />, "Align Right")}
        {toolbarBtn("justifyFull", <AlignJustify size={13} />, "Justify")}
        <div style={{ width: 1, height: 14, background: "#ccc", margin: "0 2px" }} />
        {toolbarBtn("insertUnorderedList", <List size={13} />, "Bullet List")}
        {toolbarBtn("insertOrderedList", <ListOrdered size={13} />, "Numbered List")}
        {toolbarBtn("indent", <Indent size={13} />, "Indent")}
        {toolbarBtn("outdent", <Outdent size={13} />, "Outdent")}
        <div style={{ width: 1, height: 14, background: "#ccc", margin: "0 2px" }} />
        <button onMouseDown={(e) => { e.preventDefault(); insertLink(); }} style={tbBtn} title="Insert Link"><Link size={13} /></button>
        <button onMouseDown={(e) => { e.preventDefault(); setShowTable(!showTable); }} style={tbBtn} title="Insert Table"><Table size={13} /></button>
        <div style={{ width: 1, height: 14, background: "#ccc", margin: "0 2px" }} />
        {/* Text color */}
        <label style={{ display: "flex", alignItems: "center", gap: 2, cursor: "pointer" }} title="Text Color">
          <Type size={13} />
          <input type="color" defaultValue="#000000" onChange={(e) => exec("foreColor", e.target.value)} style={{ width: 16, height: 16, padding: 0, border: "none", cursor: "pointer" }} />
        </label>
        {/* Highlight */}
        <label style={{ display: "flex", alignItems: "center", gap: 2, cursor: "pointer" }} title="Highlight">
          <span style={{ fontSize: "0.7rem" }}>H</span>
          <input type="color" defaultValue="#ffff00" onChange={(e) => exec("hiliteColor", e.target.value)} style={{ width: 16, height: 16, padding: 0, border: "none", cursor: "pointer" }} />
        </label>
      </div>

      {/* Table insert panel */}
      {showTable && (
        <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 12px", background: "#e8e8e8", borderBottom: "1px solid #ccc" }}>
          <span style={{ fontSize: "0.75rem" }}>Rows:</span>
          <input type="number" min={1} max={20} value={tableRows} onChange={(e) => setTableRows(Number(e.target.value))} style={{ width: 50, padding: "2px 4px", border: "1px solid #ccc", borderRadius: 3, fontSize: "0.75rem" }} />
          <span style={{ fontSize: "0.75rem" }}>Cols:</span>
          <input type="number" min={1} max={20} value={tableCols} onChange={(e) => setTableCols(Number(e.target.value))} style={{ width: 50, padding: "2px 4px", border: "1px solid #ccc", borderRadius: 3, fontSize: "0.75rem" }} />
          <button onClick={insertTable} style={{ padding: "3px 10px", background: "#3584e4", border: "none", borderRadius: 4, color: "white", cursor: "pointer", fontSize: "0.75rem" }}>Insert</button>
          <button onClick={() => setShowTable(false)} style={{ padding: "3px 8px", background: "#ccc", border: "none", borderRadius: 4, cursor: "pointer", fontSize: "0.75rem" }}>Cancel</button>
        </div>
      )}

      {/* Find/Replace */}
      {showSearch && (
        <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 12px", background: "#e8e8e8", borderBottom: "1px solid #ccc", flexWrap: "wrap" }}>
          <input value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} placeholder="Find..." style={{ padding: "3px 8px", border: "1px solid #ccc", borderRadius: 4, fontSize: "0.8rem", width: 140 }} />
          <input value={replaceTerm} onChange={(e) => setReplaceTerm(e.target.value)} placeholder="Replace..." style={{ padding: "3px 8px", border: "1px solid #ccc", borderRadius: 4, fontSize: "0.8rem", width: 140 }} />
          <button onClick={handleSearch} style={{ padding: "3px 10px", background: "#3584e4", border: "none", borderRadius: 4, color: "white", cursor: "pointer", fontSize: "0.75rem" }}>Find</button>
          <button onClick={handleReplace} style={{ padding: "3px 10px", background: "#e66100", border: "none", borderRadius: 4, color: "white", cursor: "pointer", fontSize: "0.75rem" }}>Replace All</button>
        </div>
      )}

      {/* Document area */}
      <div style={{ flex: 1, overflow: "auto", background: "#888", padding: "24px", display: "flex", justifyContent: "center" }}>
        <div
          style={{
            width: `${Math.min(816, 816 * zoom / 100)}px`,
            minHeight: 1056,
            background: "white",
            boxShadow: "0 4px 20px rgba(0,0,0,0.3)",
            padding: "72px 96px",
            transform: `scale(${zoom / 100})`,
            transformOrigin: "top center",
          }}
        >
          <div
            ref={editorRef}
            contentEditable
            suppressContentEditableWarning
            onInput={updateStats}
            style={{
              outline: "none", minHeight: "100%",
              fontFamily, fontSize: `${fontSize}pt`, lineHeight: 1.6,
              color: "#000",
            }}
            data-testid="libreoffice-editor"
            dangerouslySetInnerHTML={{ __html: "<p>Start typing your document here...</p>" }}
          />
        </div>
      </div>

      {/* Status bar */}
      <div style={{ padding: "3px 12px", fontSize: "0.65rem", color: "#666", borderTop: "1px solid #ccc", display: "flex", gap: 16, background: "#e8e8e8" }}>
        <span>Page {pageCount} of {pageCount}</span>
        <span>{wordCount} words</span>
        <span>{charCount} characters</span>
        <span>{fontFamily} {fontSize}pt</span>
      </div>
    </div>
  );
}

const tbBtn = {
  background: "none", border: "1px solid transparent", color: "#333", cursor: "pointer",
  padding: "3px 5px", borderRadius: 3, display: "flex", alignItems: "center",
};
const menuBtnStyle = {
  display: "flex", alignItems: "center", gap: 4, padding: "3px 8px",
  background: "none", border: "none", color: "#333", cursor: "pointer",
  fontSize: "0.75rem", borderRadius: 4,
};
