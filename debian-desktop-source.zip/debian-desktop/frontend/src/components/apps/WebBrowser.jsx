import { useState, useRef, useCallback } from "react";
import {
  ArrowLeft, ArrowRight, RefreshCw, X, Plus, Home, Bookmark, BookmarkCheck,
  Star, History, Shield, Lock, Globe, Search,
} from "lucide-react";

const DEFAULT_BOOKMARKS = [
  { title: "Debian", url: "https://www.debian.org", icon: "🐧" },
  { title: "GitHub", url: "https://github.com", icon: "🐙" },
  { title: "MDN Web Docs", url: "https://developer.mozilla.org", icon: "📚" },
  { title: "Stack Overflow", url: "https://stackoverflow.com", icon: "💬" },
  { title: "Wikipedia", url: "https://en.wikipedia.org", icon: "📖" },
  { title: "Linux Kernel", url: "https://kernel.org", icon: "🐧" },
];

const SEARCH_ENGINES = {
  google: "https://www.google.com/search?q=",
  bing: "https://www.bing.com/search?q=",
  duckduckgo: "https://duckduckgo.com/?q=",
};

function isUrl(str) {
  return /^https?:\/\//i.test(str) || /^[a-z0-9-]+\.[a-z]{2,}/i.test(str);
}

function normalizeUrl(str) {
  if (/^https?:\/\//i.test(str)) return str;
  if (/^[a-z0-9-]+\.[a-z]{2,}/i.test(str)) return "https://" + str;
  return SEARCH_ENGINES.google + encodeURIComponent(str);
}

export default function WebBrowser() {
  const [tabs, setTabs] = useState([
    { id: 1, url: "https://www.debian.org", title: "Debian", loading: false, history: ["https://www.debian.org"], histIdx: 0 },
  ]);
  const [activeTab, setActiveTab] = useState(1);
  const [urlInput, setUrlInput] = useState("https://www.debian.org");
  const [bookmarks, setBookmarks] = useState(DEFAULT_BOOKMARKS);
  const [showBookmarks, setShowBookmarks] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [browserHistory, setBrowserHistory] = useState([]);
  const [searchEngine, setSearchEngine] = useState("google");
  const iframeRef = useRef(null);

  const currentTab = tabs.find((t) => t.id === activeTab);

  const navigate = useCallback((url, tabId = activeTab) => {
    const normalized = normalizeUrl(url);
    setTabs((prev) => prev.map((t) => {
      if (t.id !== tabId) return t;
      const newHistory = [...t.history.slice(0, t.histIdx + 1), normalized];
      return { ...t, url: normalized, loading: true, history: newHistory, histIdx: newHistory.length - 1, title: "Loading..." };
    }));
    setUrlInput(normalized);
    setBrowserHistory((h) => [{ url: normalized, title: url, time: new Date() }, ...h.slice(0, 99)]);
    setShowBookmarks(false);
    setShowHistory(false);
  }, [activeTab]);

  const handleUrlSubmit = (e) => {
    e.preventDefault();
    navigate(urlInput);
  };

  const goBack = () => {
    setTabs((prev) => prev.map((t) => {
      if (t.id !== activeTab || t.histIdx <= 0) return t;
      const newIdx = t.histIdx - 1;
      const url = t.history[newIdx];
      setUrlInput(url);
      return { ...t, url, histIdx: newIdx, loading: true };
    }));
  };

  const goForward = () => {
    setTabs((prev) => prev.map((t) => {
      if (t.id !== activeTab || t.histIdx >= t.history.length - 1) return t;
      const newIdx = t.histIdx + 1;
      const url = t.history[newIdx];
      setUrlInput(url);
      return { ...t, url, histIdx: newIdx, loading: true };
    }));
  };

  const refresh = () => {
    setTabs((prev) => prev.map((t) => t.id === activeTab ? { ...t, loading: true } : t));
    if (iframeRef.current) {
      try { iframeRef.current.src = currentTab?.url; } catch {}
    }
  };

  const newTab = () => {
    const id = Date.now();
    setTabs((prev) => [...prev, { id, url: "about:blank", title: "New Tab", loading: false, history: ["about:blank"], histIdx: 0 }]);
    setActiveTab(id);
    setUrlInput("");
  };

  const closeTab = (tabId, e) => {
    e.stopPropagation();
    if (tabs.length === 1) { newTab(); }
    setTabs((prev) => prev.filter((t) => t.id !== tabId));
    if (activeTab === tabId) {
      const remaining = tabs.filter((t) => t.id !== tabId);
      if (remaining.length > 0) setActiveTab(remaining[remaining.length - 1].id);
    }
  };

  const toggleBookmark = () => {
    if (!currentTab) return;
    const existing = bookmarks.find((b) => b.url === currentTab.url);
    if (existing) {
      setBookmarks((b) => b.filter((bk) => bk.url !== currentTab.url));
    } else {
      setBookmarks((b) => [...b, { title: currentTab.title, url: currentTab.url, icon: "⭐" }]);
    }
  };

  const isBookmarked = bookmarks.some((b) => b.url === currentTab?.url);

  const onIframeLoad = (tabId) => {
    setTabs((prev) => prev.map((t) => {
      if (t.id !== tabId) return t;
      let title = t.url;
      try {
        const u = new URL(t.url);
        title = u.hostname.replace("www.", "");
      } catch {}
      return { ...t, loading: false, title };
    }));
  };

  return (
    <div className="web-browser" data-testid="web-browser-app" style={{ flexDirection: "column" }}>
      {/* Tab bar */}
      <div style={{ display: "flex", alignItems: "center", background: "#1a1a1a", borderBottom: "1px solid rgba(255,255,255,0.08)", overflowX: "auto", minHeight: 36 }}>
        {tabs.map((tab) => (
          <div
            key={tab.id}
            onClick={() => { setActiveTab(tab.id); setUrlInput(tab.url); }}
            style={{
              display: "flex", alignItems: "center", gap: 6, padding: "6px 12px", cursor: "pointer",
              background: tab.id === activeTab ? "#2a2a2a" : "transparent",
              borderRight: "1px solid rgba(255,255,255,0.06)",
              minWidth: 120, maxWidth: 200, flexShrink: 0,
              borderTop: tab.id === activeTab ? "2px solid #3584e4" : "2px solid transparent",
            }}
            data-testid={`browser-tab-${tab.id}`}
          >
            <Globe size={12} color="#5e5c64" style={{ flexShrink: 0 }} />
            <span style={{ flex: 1, fontSize: "0.75rem", color: "white", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {tab.loading ? "Loading..." : tab.title}
            </span>
            <button
              onClick={(e) => closeTab(tab.id, e)}
              style={{ background: "none", border: "none", color: "#5e5c64", cursor: "pointer", padding: 2, borderRadius: 2, flexShrink: 0 }}
              data-testid={`browser-close-tab-${tab.id}`}
            ><X size={10} /></button>
          </div>
        ))}
        <button
          onClick={newTab}
          style={{ padding: "6px 10px", background: "none", border: "none", color: "#9a9996", cursor: "pointer", flexShrink: 0 }}
          data-testid="browser-new-tab"
        ><Plus size={14} /></button>
      </div>

      {/* Navigation bar */}
      <div className="browser-nav" style={{ gap: 6, padding: "6px 8px" }}>
        <button className="browser-nav-btn" onClick={goBack} disabled={!currentTab || currentTab.histIdx <= 0} data-testid="browser-back"><ArrowLeft size={16} /></button>
        <button className="browser-nav-btn" onClick={goForward} disabled={!currentTab || currentTab.histIdx >= (currentTab.history.length - 1)} data-testid="browser-forward"><ArrowRight size={16} /></button>
        <button className="browser-nav-btn" onClick={refresh} data-testid="browser-refresh"><RefreshCw size={14} /></button>
        <button className="browser-nav-btn" onClick={() => navigate("https://www.debian.org")} data-testid="browser-home"><Home size={14} /></button>

        {/* URL bar */}
        <form onSubmit={handleUrlSubmit} style={{ flex: 1, display: "flex", alignItems: "center", gap: 4, background: "rgba(255,255,255,0.06)", borderRadius: 20, padding: "4px 12px" }}>
          {currentTab?.url?.startsWith("https") ? <Lock size={12} color="#26a269" /> : <Globe size={12} color="#5e5c64" />}
          <input
            className="browser-url-input"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            onFocus={(e) => e.target.select()}
            placeholder="Search or enter URL..."
            style={{ flex: 1, background: "none", border: "none", outline: "none", color: "white", fontSize: "0.8rem" }}
            data-testid="browser-url-input"
          />
          {urlInput && <button type="button" onClick={() => setUrlInput("")} style={{ background: "none", border: "none", color: "#5e5c64", cursor: "pointer", padding: 0 }}><X size={12} /></button>}
        </form>

        <button
          className="browser-nav-btn"
          onClick={toggleBookmark}
          style={{ color: isBookmarked ? "#f8e45c" : undefined }}
          title={isBookmarked ? "Remove Bookmark" : "Add Bookmark"}
          data-testid="browser-bookmark"
        >{isBookmarked ? <BookmarkCheck size={14} /> : <Bookmark size={14} />}</button>
        <button className="browser-nav-btn" onClick={() => { setShowBookmarks(!showBookmarks); setShowHistory(false); }} style={{ color: showBookmarks ? "#3584e4" : undefined }} data-testid="browser-show-bookmarks"><Star size={14} /></button>
        <button className="browser-nav-btn" onClick={() => { setShowHistory(!showHistory); setShowBookmarks(false); }} style={{ color: showHistory ? "#3584e4" : undefined }} data-testid="browser-show-history"><History size={14} /></button>
        <button className="browser-nav-btn" title="Privacy Mode"><Shield size={14} /></button>
      </div>

      {/* Bookmarks bar */}
      {DEFAULT_BOOKMARKS.slice(0, 6).map((b) => (
        <button
          key={b.url}
          onClick={() => navigate(b.url)}
          style={{ display: "inline-flex", alignItems: "center", gap: 4, padding: "2px 8px", background: "none", border: "none", color: "#9a9996", cursor: "pointer", fontSize: "0.7rem", borderBottom: "1px solid rgba(255,255,255,0.04)" }}
        >
          <span>{b.icon}</span>{b.title}
        </button>
      ))}

      {/* Main content */}
      <div style={{ flex: 1, position: "relative", overflow: "hidden" }}>
        {showBookmarks && (
          <div style={{ position: "absolute", top: 0, right: 0, width: 280, height: "100%", background: "#1e1e1e", borderLeft: "1px solid rgba(255,255,255,0.08)", zIndex: 10, overflowY: "auto", padding: 12 }}>
            <div style={{ fontWeight: 600, color: "white", marginBottom: 12, fontSize: "0.875rem" }}>Bookmarks</div>
            {bookmarks.map((b) => (
              <button key={b.url} onClick={() => navigate(b.url)} style={{ display: "flex", alignItems: "center", gap: 8, width: "100%", padding: "8px 8px", background: "none", border: "none", color: "white", cursor: "pointer", borderRadius: 6, fontSize: "0.8rem", textAlign: "left" }}>
                <span>{b.icon}</span>
                <div>
                  <div>{b.title}</div>
                  <div style={{ fontSize: "0.65rem", color: "#5e5c64", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 200 }}>{b.url}</div>
                </div>
              </button>
            ))}
          </div>
        )}
        {showHistory && (
          <div style={{ position: "absolute", top: 0, right: 0, width: 280, height: "100%", background: "#1e1e1e", borderLeft: "1px solid rgba(255,255,255,0.08)", zIndex: 10, overflowY: "auto", padding: 12 }}>
            <div style={{ fontWeight: 600, color: "white", marginBottom: 12, fontSize: "0.875rem" }}>History</div>
            {browserHistory.length === 0 && <div style={{ fontSize: "0.75rem", color: "#5e5c64" }}>No history yet</div>}
            {browserHistory.map((h, i) => (
              <button key={i} onClick={() => navigate(h.url)} style={{ display: "flex", flexDirection: "column", width: "100%", padding: "6px 8px", background: "none", border: "none", color: "white", cursor: "pointer", borderRadius: 6, fontSize: "0.8rem", textAlign: "left" }}>
                <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 240 }}>{h.url}</span>
                <span style={{ fontSize: "0.65rem", color: "#5e5c64" }}>{h.time.toLocaleTimeString()}</span>
              </button>
            ))}
          </div>
        )}

        {currentTab && (
          currentTab.url === "about:blank" ? (
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", gap: 24, background: "#1a1a1a" }}>
              <div style={{ fontSize: "1.5rem", color: "#9a9996" }}>New Tab</div>
              <form onSubmit={handleUrlSubmit} style={{ display: "flex", gap: 8, width: "100%", maxWidth: 500, padding: "0 24px" }}>
                <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 8, background: "rgba(255,255,255,0.08)", borderRadius: 24, padding: "10px 16px" }}>
                  <Search size={16} color="#5e5c64" />
                  <input
                    value={urlInput}
                    onChange={(e) => setUrlInput(e.target.value)}
                    placeholder="Search the web or enter a URL..."
                    style={{ flex: 1, background: "none", border: "none", outline: "none", color: "white", fontSize: "0.9rem" }}
                    autoFocus
                  />
                </div>
              </form>
              <div style={{ display: "flex", gap: 16, flexWrap: "wrap", justifyContent: "center", maxWidth: 500, padding: "0 24px" }}>
                {DEFAULT_BOOKMARKS.map((b) => (
                  <button key={b.url} onClick={() => navigate(b.url)} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6, padding: "12px 16px", background: "rgba(255,255,255,0.06)", border: "none", borderRadius: 12, color: "white", cursor: "pointer", minWidth: 80 }}>
                    <span style={{ fontSize: "1.5rem" }}>{b.icon}</span>
                    <span style={{ fontSize: "0.75rem" }}>{b.title}</span>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <iframe
              ref={iframeRef}
              src={currentTab.url}
              style={{ width: "100%", height: "100%", border: "none" }}
              onLoad={() => onIframeLoad(currentTab.id)}
              title="browser-content"
              sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-top-navigation"
              data-testid="browser-iframe"
            />
          )
        )}
      </div>
    </div>
  );
}
